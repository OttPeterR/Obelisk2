public interface AI extends Entity
{
	void getPlayerLocation(double inx, double iny);
}
